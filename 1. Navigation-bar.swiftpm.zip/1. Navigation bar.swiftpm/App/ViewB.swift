import SwiftUI

struct ViewB: View {
    var body: some View {
        
        ZStack {
            Color(red: 150 / 255, green: 226 / 255, blue: 255 / 255)
            Image(systemName: "house.circle")
                .foregroundColor(Color.white) 
                .font(.system(size: 100.0))
        }
    }
}

struct ViewB_Previews: PreviewProvider {
    static var previews: some View {
        ViewB()
    }
}

