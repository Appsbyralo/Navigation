import SwiftUI

struct ViewC: View {
    
    @State private var color: Color = .black
    
    var body: some View {
        
        ZStack {
            
            color
            
            VStack {
                Spacer() 
                
                
                Image(systemName: "questionmark.circle")
                    .foregroundColor(Color.white)
                    .font(.system(size: 100.0)) 
                
                Spacer() 
                
                ColorPicker("Color Picker", selection: $color)
                    .labelsHidden() 
                
                
                Label("Choose a color", systemImage: "paintpalette")
                    .symbolVariant(.fill) 
                    .foregroundColor(.white)
                
                Spacer()
                
                Rectangle()
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.red, Color.orange, Color.yellow, Color.green, 
                                Color.blue, Color.indigo, Color.purple, Color.pink
                            ]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: 400, height: 100)
                    .padding(.bottom, 50) 
                
                VStack {
                    Text("Tasks:")
                        .font(.headline)
                        .padding(.top, 20)
                        .foregroundColor(.white)
                    
                    Text("1. Use the color picker to choose the color you like.")
                        .padding(.top, 5)
                        .foregroundColor(.white)
                    
                    Text("2. Can you make the background color into a gradient?")
                        .padding(.top, 5)
                        .foregroundColor(.white)
                }
                .padding(.bottom, 50) 
            }
        }
    }
}

struct ViewC_Previews: PreviewProvider {
    static var previews: some View {
        ViewC()
    }
}

