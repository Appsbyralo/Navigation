import SwiftUI


struct ContentView: View {
    var body: some View {
        /*#-code-walkthrough(1.modifier)*/
        TabView {
            /*#-code-walkthrough(1.1.modifier)*/
            ViewA()
                .tabItem() {
                    Image(systemName: "airplane.circle")  
                    Text("Text A")
                }
            /*#-code-walkthrough(1.1.modifier)*/
            ViewB()
                .tabItem() {
                    Image(systemName: "house.circle")
                    Text("Text B")
                }
            
            ViewC()
                .tabItem() {
                    Image(systemName: "questionmark.circle")
                    Text("Text C")
                }
        }
    }
    /*#-code-walkthrough(1.modifier)*/
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

